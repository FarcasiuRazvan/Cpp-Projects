#include "FileShelter.h"



FileShelter::FileShelter(const std::string& filename)
{
	this->filename = filename;
}