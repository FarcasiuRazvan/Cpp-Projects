//#include "lab1012.h"
//
//lab1012::lab1012(QWidget *parent)
//	: QWidget(parent)
//{
//	//ui.setupUi(this);
//	
//	//model = new QStringListModel(this);
//	//QStringList list;
//	//
//	//list << "cats" << "dogs" << "birds";
//	//
//	//model->setStringList(list);
//	//model = new QAbstractTableModel(this);
//
//}
