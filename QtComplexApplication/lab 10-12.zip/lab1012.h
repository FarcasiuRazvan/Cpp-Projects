//#pragma once
//
//#include <QtCore>
//#include <QtGui>
//#include <QtWidgets>
//#include <QtWidgets/QMainWindow>
//#include "ui_lab1012.h"
//
//class lab1012 : public QWidget
//{
//	Q_OBJECT
//
//public:
//	lab1012(QWidget *parent = Q_NULLPTR);
//
//private:
//	//Ui::lab1012 ui;
//	//QStringListModel *model;
//
//	//QAbstractTableModel *model;
//
//};
